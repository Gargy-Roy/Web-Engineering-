function contactMe() {
  alert("You can contact Gargy Roy:\n\nPhone: 01706587414\nEmail: roy15-4783@diu.edu.bd");
}
